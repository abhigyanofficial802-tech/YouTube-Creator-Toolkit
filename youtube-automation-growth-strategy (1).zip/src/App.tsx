import { useState } from 'react';
import ScriptWriter from './components/ScriptWriter';
import SEOOptimizer from './components/SEOOptimizer';
import ChannelPlanner from './components/ChannelPlanner';
import ContentRepurposer from './components/ContentRepurposer';
import ToolsLibrary from './components/ToolsLibrary';

type Tab = 'script' | 'seo' | 'planner' | 'repurpose' | 'tools';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('script');
  const [globalTopic, setGlobalTopic] = useState('trading');

  const tabs: { id: Tab; label: string; icon: string; gradient: string }[] = [
    { id: 'script', label: 'Script Writer', icon: '📝', gradient: 'from-red-500 to-pink-500' },
    { id: 'seo', label: 'SEO Optimizer', icon: '🔍', gradient: 'from-green-500 to-teal-500' },
    { id: 'planner', label: '30-Day Planner', icon: '📅', gradient: 'from-purple-500 to-indigo-500' },
    { id: 'repurpose', label: 'Repurposer', icon: '♻️', gradient: 'from-orange-500 to-amber-500' },
    { id: 'tools', label: 'Tools Library', icon: '🛠️', gradient: 'from-cyan-500 to-blue-500' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-pink-500 rounded-xl flex items-center justify-center">
                <span className="text-white text-xl">▶️</span>
              </div>
              <div>
                <h1 className="font-bold text-gray-800 text-lg">YouTube Creator Toolkit</h1>
                <p className="text-xs text-gray-500">AI-Powered Content Creation Suite</p>
              </div>
            </div>
            <div className="hidden md:flex items-center gap-2 bg-gray-100 rounded-full px-4 py-2">
              <span className="text-sm text-gray-600">Topic:</span>
              <input
                type="text"
                value={globalTopic}
                onChange={(e) => setGlobalTopic(e.target.value)}
                className="bg-transparent border-none focus:outline-none text-sm font-medium text-gray-800 w-32"
                placeholder="your niche..."
              />
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-white border-b border-gray-200 sticky top-[73px] z-40">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex overflow-x-auto scrollbar-hide -mb-px">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-6 py-4 border-b-2 transition whitespace-nowrap ${
                  activeTab === tab.id
                    ? `border-gray-800 text-gray-800`
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <span>{tab.icon}</span>
                <span className="font-medium text-sm">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-2xl p-4 border border-gray-200 shadow-sm">
            <div className="text-3xl mb-2">📝</div>
            <div className="text-2xl font-bold text-gray-800">∞</div>
            <div className="text-xs text-gray-500">Scripts Generated</div>
          </div>
          <div className="bg-white rounded-2xl p-4 border border-gray-200 shadow-sm">
            <div className="text-3xl mb-2">🎬</div>
            <div className="text-2xl font-bold text-gray-800">5</div>
            <div className="text-xs text-gray-500">Content Formats</div>
          </div>
          <div className="bg-white rounded-2xl p-4 border border-gray-200 shadow-sm">
            <div className="text-3xl mb-2">🛠️</div>
            <div className="text-2xl font-bold text-gray-800">20+</div>
            <div className="text-xs text-gray-500">Creator Tools</div>
          </div>
          <div className="bg-white rounded-2xl p-4 border border-gray-200 shadow-sm">
            <div className="text-3xl mb-2">💰</div>
            <div className="text-2xl font-bold text-gray-800">$0</div>
            <div className="text-xs text-gray-500">To Start</div>
          </div>
        </div>

        {/* Active Tab Content */}
        <div className="bg-white rounded-3xl p-6 md:p-8 border border-gray-200 shadow-sm">
          {activeTab === 'script' && (
            <ScriptWriter topic={globalTopic} setTopic={setGlobalTopic} />
          )}
          {activeTab === 'seo' && (
            <SEOOptimizer topic={globalTopic} setTopic={setGlobalTopic} />
          )}
          {activeTab === 'planner' && <ChannelPlanner />}
          {activeTab === 'repurpose' && (
            <ContentRepurposer topic={globalTopic} setTopic={setGlobalTopic} />
          )}
          {activeTab === 'tools' && <ToolsLibrary />}
        </div>

        {/* How It Works */}
        <div className="mt-8 bg-gradient-to-br from-gray-900 to-gray-800 rounded-3xl p-8 text-white">
          <h2 className="text-2xl font-bold mb-6 text-center">🚀 How to Build a Faceless YouTube Channel</h2>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-white/10 rounded-2xl flex items-center justify-center text-3xl mb-4">
                📝
              </div>
              <h3 className="font-bold mb-2">1. Write Script</h3>
              <p className="text-sm text-gray-400">Use ChatGPT or our Script Writer to create engaging content</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-white/10 rounded-2xl flex items-center justify-center text-3xl mb-4">
                🎙️
              </div>
              <h3 className="font-bold mb-2">2. Add Voice</h3>
              <p className="text-sm text-gray-400">Generate realistic AI voiceover with ElevenLabs or Murf</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-white/10 rounded-2xl flex items-center justify-center text-3xl mb-4">
                🎬
              </div>
              <h3 className="font-bold mb-2">3. Create Video</h3>
              <p className="text-sm text-gray-400">Auto-match footage with Pictory or edit in CapCut</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-white/10 rounded-2xl flex items-center justify-center text-3xl mb-4">
                📈
              </div>
              <h3 className="font-bold mb-2">4. Optimize & Post</h3>
              <p className="text-sm text-gray-400">Use our SEO tools and TubeBuddy to maximize reach</p>
            </div>
          </div>
        </div>

        {/* Tips Section */}
        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-red-50 to-pink-50 rounded-2xl p-6 border border-red-100">
            <div className="text-3xl mb-3">💡</div>
            <h3 className="font-bold text-gray-800 mb-2">Pro Tip: Hook First</h3>
            <p className="text-sm text-gray-600">
              Your first 5 seconds determine if viewers stay. Always start with a pattern interrupt,
              bold claim, or curiosity gap.
            </p>
          </div>
          <div className="bg-gradient-to-br from-green-50 to-teal-50 rounded-2xl p-6 border border-green-100">
            <div className="text-3xl mb-3">📊</div>
            <h3 className="font-bold text-gray-800 mb-2">Track Your Metrics</h3>
            <p className="text-sm text-gray-600">
              Focus on CTR (click-through rate) and AVD (average view duration).
              These two metrics drive YouTube's algorithm.
            </p>
          </div>
          <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-2xl p-6 border border-purple-100">
            <div className="text-3xl mb-3">🎯</div>
            <h3 className="font-bold text-gray-800 mb-2">Consistency Wins</h3>
            <p className="text-sm text-gray-600">
              Upload at least 2x per week for 6 months before judging results.
              The algorithm rewards consistent creators.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-red-500 to-pink-500 rounded-lg flex items-center justify-center">
                <span className="text-white text-sm">▶️</span>
              </div>
              <span className="font-medium text-gray-800">YouTube Creator Toolkit</span>
            </div>
            <p className="text-sm text-gray-500">
              Build your faceless YouTube empire with AI-powered tools ✨
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 hover:text-gray-600 transition">
                <span className="text-xl">🐦</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-gray-600 transition">
                <span className="text-xl">📸</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-gray-600 transition">
                <span className="text-xl">🎵</span>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
