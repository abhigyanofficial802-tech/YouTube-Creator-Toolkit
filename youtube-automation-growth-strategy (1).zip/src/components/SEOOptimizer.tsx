import { useState } from 'react';

interface SEOOptimizerProps {
  topic: string;
  setTopic: (topic: string) => void;
}

export default function SEOOptimizer({ topic, setTopic }: SEOOptimizerProps) {
  const [seoContent, setSeoContent] = useState<{
    titles: string[];
    description: string;
    tags: string[];
    thumbnail: string[];
  } | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const generateSEO = () => {
    if (!topic.trim()) return;
    setIsGenerating(true);

    setTimeout(() => {
      const topicCap = topic.charAt(0).toUpperCase() + topic.slice(1);
      
      setSeoContent({
        titles: [
          `I Tried ${topicCap} For 30 Days - Here's What Happened 😱`,
          `The ${topicCap} Secret Nobody Tells You (Until Now)`,
          `${topicCap} For Beginners: Complete Guide 2024`,
          `Why 99% of People FAIL at ${topicCap} (And How to Be the 1%)`,
          `${topicCap} Masterclass: From Zero to Hero in 7 Days`,
          `I Asked AI About ${topicCap} And It Changed Everything`,
          `STOP Making These ${topicCap} Mistakes (I Lost $10,000)`,
          `The ONLY ${topicCap} Video You'll Ever Need`,
        ],
        description: `🚀 Welcome to the ultimate guide on ${topic}!

In this video, I'm breaking down everything you need to know about ${topic} - from complete beginner to advanced strategies that actually work in 2024.

⏰ TIMESTAMPS:
0:00 - Introduction & Hook
0:45 - Why ${topic} Matters Now
2:30 - The Fundamentals Explained
5:15 - 5 Strategies That Actually Work
8:00 - Common Mistakes to Avoid
10:30 - Advanced Tips & Tricks
12:00 - Final Thoughts & CTA

🎁 FREE RESOURCES:
📚 Download my FREE ${topic} Cheat Sheet: [LINK]
📧 Join my Newsletter: [LINK]
💬 Join our Discord Community: [LINK]

🔗 RECOMMENDED TOOLS:
• Tool 1 (Affiliate Link): [LINK]
• Tool 2 (Affiliate Link): [LINK]
• Tool 3 (Affiliate Link): [LINK]

📱 CONNECT WITH ME:
Instagram: @yourhandle
Twitter: @yourhandle
TikTok: @yourhandle

📺 WATCH NEXT:
▶️ [Related Video 1]: [LINK]
▶️ [Related Video 2]: [LINK]

#${topic.replace(/\s+/g, '')} #${topic.replace(/\s+/g, '')}tips #${topic.replace(/\s+/g, '')}2024 #howto #tutorial #beginners #guide

⚠️ DISCLAIMER: This video is for educational purposes only. Results may vary.

Thanks for watching! Don't forget to LIKE, SUBSCRIBE, and hit the 🔔 bell for more content like this!`,
        tags: [
          topic,
          `${topic} tutorial`,
          `${topic} for beginners`,
          `${topic} 2024`,
          `${topic} guide`,
          `${topic} tips`,
          `${topic} mistakes`,
          `${topic} secrets`,
          `how to ${topic}`,
          `${topic} strategy`,
          `${topic} masterclass`,
          `learn ${topic}`,
          `${topic} explained`,
          `${topic} tips and tricks`,
          `best ${topic} strategies`,
          `${topic} for dummies`,
          `${topic} crash course`,
          `${topic} made easy`,
        ],
        thumbnail: [
          `🎨 THUMBNAIL IDEA 1: "Before/After Split"
• Left side: Frustrated person / red X
• Right side: Successful person / green checkmark
• Bold text: "${topicCap.toUpperCase()}" + "SECRETS"
• Your face with surprised expression`,
          
          `🎨 THUMBNAIL IDEA 2: "Money Shot"
• Cash/coins visual element
• Arrow pointing up 📈
• Text: "$0 → $10K" or similar
• Bright yellow/green background`,
          
          `🎨 THUMBNAIL IDEA 3: "Pattern Interrupt"
• Unusual color scheme (purple/orange)
• Close-up shocked face
• Crossed out common myth
• Text: "STOP doing this!"`,
          
          `🎨 THUMBNAIL IDEA 4: "Listicle Style"
• Number in corner (5, 7, 10)
• Icons representing each point
• Clean, minimal design
• Text: "The ${topicCap} Formula"`,
        ],
      });
      setIsGenerating(false);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-green-500 to-teal-500 rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">🔍 YouTube SEO Optimizer</h2>
        <p className="opacity-90">Generate high-ranking titles, descriptions, tags & thumbnail ideas</p>
      </div>

      <div className="flex gap-4">
        <input
          type="text"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder="Enter your video topic..."
          className="flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-green-500 focus:border-transparent transition"
        />
        <button
          onClick={generateSEO}
          disabled={!topic.trim() || isGenerating}
          className="px-6 py-3 bg-gradient-to-r from-green-500 to-teal-500 text-white font-bold rounded-xl hover:opacity-90 transition disabled:opacity-50"
        >
          {isGenerating ? '⏳' : '🚀'} Optimize
        </button>
      </div>

      {seoContent && (
        <div className="space-y-6">
          {/* Titles */}
          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <span className="text-2xl">🏆</span> High-Ranking Title Options
            </h3>
            <div className="space-y-2">
              {seoContent.titles.map((title, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-green-50 transition cursor-pointer group"
                  onClick={() => navigator.clipboard.writeText(title)}
                >
                  <span className="text-gray-700">{title}</span>
                  <span className="text-xs text-gray-400 group-hover:text-green-600">Click to copy</span>
                </div>
              ))}
            </div>
          </div>

          {/* Description */}
          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-gray-800 flex items-center gap-2">
                <span className="text-2xl">📝</span> Optimized Description
              </h3>
              <button
                onClick={() => navigator.clipboard.writeText(seoContent.description)}
                className="px-4 py-2 bg-green-500 text-white rounded-lg text-sm hover:bg-green-600 transition"
              >
                📋 Copy
              </button>
            </div>
            <pre className="whitespace-pre-wrap text-sm text-gray-700 bg-gray-50 p-4 rounded-xl max-h-[300px] overflow-y-auto">
              {seoContent.description}
            </pre>
          </div>

          {/* Tags */}
          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-gray-800 flex items-center gap-2">
                <span className="text-2xl">🏷️</span> SEO Tags
              </h3>
              <button
                onClick={() => navigator.clipboard.writeText(seoContent.tags.join(', '))}
                className="px-4 py-2 bg-green-500 text-white rounded-lg text-sm hover:bg-green-600 transition"
              >
                📋 Copy All
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {seoContent.tags.map((tag, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm cursor-pointer hover:bg-green-200 transition"
                  onClick={() => navigator.clipboard.writeText(tag)}
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>

          {/* Thumbnail Ideas */}
          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <span className="text-2xl">🖼️</span> Thumbnail Ideas
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              {seoContent.thumbnail.map((idea, idx) => (
                <div key={idx} className="p-4 bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl border border-gray-200">
                  <pre className="whitespace-pre-wrap text-sm text-gray-700">{idea}</pre>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
