import { useState } from 'react';

export default function ChannelPlanner() {
  const [niche, setNiche] = useState('');
  const [plan, setPlan] = useState<{
    week1: string[];
    week2: string[];
    week3: string[];
    week4: string[];
    schedule: string;
    growth: string[];
    monetization: string[];
  } | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const generatePlan = () => {
    if (!niche.trim()) return;
    setIsGenerating(true);

    setTimeout(() => {
      const nicheCap = niche.charAt(0).toUpperCase() + niche.slice(1);
      
      setPlan({
        week1: [
          `📹 Day 1: "What is ${nicheCap}? Complete Beginner's Guide" (Pillar content)`,
          `📹 Day 3: "${nicheCap} Mistakes I Made So You Don't Have To" (Story-driven)`,
          `📹 Day 5: "5 ${nicheCap} Tools Every Beginner Needs" (Listicle)`,
          `📹 Day 7: "${nicheCap} Q&A: Answering Your Top Questions" (Engagement)`,
          `🎬 Shorts: 3-4 quick tips extracted from main videos`,
        ],
        week2: [
          `📹 Day 8: "My ${nicheCap} Journey: From Zero to [Result]" (Personal story)`,
          `📹 Day 10: "The ${nicheCap} Strategy Nobody Talks About" (Curiosity hook)`,
          `📹 Day 12: "${nicheCap} vs [Alternative]: Which is Better?" (Comparison)`,
          `📹 Day 14: "Day in My Life: ${nicheCap} Edition" (Lifestyle content)`,
          `🎬 Shorts: Behind-the-scenes + trending sounds`,
        ],
        week3: [
          `📹 Day 15: "Advanced ${nicheCap} Techniques for 2024" (Level-up content)`,
          `📹 Day 17: "I Tried ${nicheCap} for 7 Days - Results" (Challenge format)`,
          `📹 Day 19: "Reacting to ${nicheCap} Fails/Wins" (Reaction content)`,
          `📹 Day 21: "${nicheCap} Myths DEBUNKED" (Controversial/educational)`,
          `🎬 Shorts: Trending challenges related to niche`,
        ],
        week4: [
          `📹 Day 22: "Expert Interview: [Name] Shares ${nicheCap} Secrets" (Collab)`,
          `📹 Day 24: "My Honest ${nicheCap} Review After 30 Days" (Trust-building)`,
          `📹 Day 26: "The Future of ${nicheCap}: What's Coming in 2025" (Thought leadership)`,
          `📹 Day 28-30: "LIVE Q&A + Community Celebration" (Engagement boost)`,
          `🎬 Shorts: Month recap highlights + teasers for next month`,
        ],
        schedule: `📅 OPTIMAL UPLOAD SCHEDULE

**Long-form Videos:** Tuesday, Thursday, Saturday
- Best times: 2-4 PM EST (optimize for your audience later)
- Aim for 8-15 minute videos initially

**YouTube Shorts:** Daily
- Best times: 6-9 AM and 7-10 PM
- 30-60 seconds each
- Repurpose from long-form content

**Community Posts:** 3x per week
- Polls, questions, behind-the-scenes
- Build engagement and algorithm favor

**Live Streams:** Weekly (once established)
- Saturday or Sunday
- 1-2 hours for community building`,

        growth: [
          `🚀 **SEO Optimization**
• Research keywords with TubeBuddy/VidIQ
• Optimize titles, descriptions, tags
• Create custom thumbnails (CTR focus)`,
          
          `🤝 **Community Building**
• Reply to EVERY comment for first 100 videos
• Create a Discord server
• Feature viewer submissions`,
          
          `📱 **Cross-Platform Promotion**
• Share clips on TikTok, Instagram Reels
• Tweet insights and link videos
• Pinterest for evergreen content`,
          
          `🤜 **Collaboration Strategy**
• DM 5 similar-sized creators weekly
• Offer value-first partnerships
• Guest on podcasts in your niche`,
          
          `📊 **Analytics Review**
• Check analytics every Sunday
• Double down on what works
• Cut what doesn't after fair testing`,
          
          `🎯 **Content Pillars**
• 40% Educational content
• 30% Entertaining content
• 20% Inspirational/Story content
• 10% Promotional content`,
        ],

        monetization: [
          `💰 **Phase 1: Foundation (Month 1-3)**
• Focus on content quality and consistency
• Build email list from day 1
• No monetization pressure - just grow`,
          
          `💰 **Phase 2: Partner Program (Month 3-6)**
• Target: 1,000 subscribers + 4,000 watch hours
• Apply for YouTube Partner Program
• Expected CPM: $2-8 depending on niche`,
          
          `💰 **Phase 3: Affiliate Marketing (Month 4+)**
• Join Amazon Associates, ShareASale
• Review products in your niche
• Add affiliate links to descriptions
• Potential: $500-2,000/month`,
          
          `💰 **Phase 4: Sponsorships (Month 6+)**
• Create media kit at 5K+ subscribers
• Reach out to brands proactively
• Start at $50-200 per 1K subscribers`,
          
          `💰 **Phase 5: Digital Products (Month 8+)**
• Create an ebook or mini-course
• Sell templates, presets, or tools
• Offer coaching or consulting`,
          
          `💰 **Phase 6: Scale (Year 2+)**
• Launch premium course ($97-497)
• Build membership community
• Diversify with merchandise
• Target: $5,000-50,000+/month`,
        ],
      });
      setIsGenerating(false);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-purple-500 to-indigo-500 rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">📅 30-Day Channel Planner</h2>
        <p className="opacity-90">Get a complete content strategy with video ideas, schedules & monetization</p>
      </div>

      <div className="flex gap-4">
        <input
          type="text"
          value={niche}
          onChange={(e) => setNiche(e.target.value)}
          placeholder="Enter your channel niche (e.g., trading, fitness, cooking)..."
          className="flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
        />
        <button
          onClick={generatePlan}
          disabled={!niche.trim() || isGenerating}
          className="px-6 py-3 bg-gradient-to-r from-purple-500 to-indigo-500 text-white font-bold rounded-xl hover:opacity-90 transition disabled:opacity-50"
        >
          {isGenerating ? '⏳ Planning...' : '📋 Generate Plan'}
        </button>
      </div>

      {plan && (
        <div className="space-y-6">
          {/* Weekly Plans */}
          <div className="grid md:grid-cols-2 gap-4">
            {[
              { title: 'Week 1: Foundation', data: plan.week1, color: 'blue' },
              { title: 'Week 2: Momentum', data: plan.week2, color: 'green' },
              { title: 'Week 3: Expansion', data: plan.week3, color: 'yellow' },
              { title: 'Week 4: Community', data: plan.week4, color: 'red' },
            ].map((week, idx) => (
              <div key={idx} className="bg-white rounded-2xl p-5 border border-gray-200 shadow-sm">
                <h3 className={`font-bold text-gray-800 mb-3 pb-2 border-b`}>
                  📆 {week.title}
                </h3>
                <ul className="space-y-2">
                  {week.data.map((item, i) => (
                    <li key={i} className="text-sm text-gray-600">{item}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Schedule */}
          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <span className="text-2xl">⏰</span> Upload Schedule
            </h3>
            <pre className="whitespace-pre-wrap text-sm text-gray-700 bg-purple-50 p-4 rounded-xl">
              {plan.schedule}
            </pre>
          </div>

          {/* Growth Strategies */}
          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <span className="text-2xl">📈</span> Growth Strategies
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {plan.growth.map((strategy, idx) => (
                <div key={idx} className="p-4 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl">
                  <pre className="whitespace-pre-wrap text-sm text-gray-700">{strategy}</pre>
                </div>
              ))}
            </div>
          </div>

          {/* Monetization */}
          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <span className="text-2xl">💰</span> Monetization Roadmap
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {plan.monetization.map((phase, idx) => (
                <div key={idx} className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl border border-green-100">
                  <pre className="whitespace-pre-wrap text-sm text-gray-700">{phase}</pre>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
