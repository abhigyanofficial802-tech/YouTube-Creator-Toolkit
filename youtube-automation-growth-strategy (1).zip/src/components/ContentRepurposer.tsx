import { useState } from 'react';

interface ContentRepurposerProps {
  topic: string;
  setTopic: (topic: string) => void;
}

export default function ContentRepurposer({ topic, setTopic }: ContentRepurposerProps) {
  const [repurposedContent, setRepurposedContent] = useState<{
    blog: string;
    instagram: string;
    tiktok: string;
    threads: string;
    twitter: string;
    linkedin: string;
  } | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState('blog');

  const generateContent = () => {
    if (!topic.trim()) return;
    setIsGenerating(true);

    setTimeout(() => {
      const topicCap = topic.charAt(0).toUpperCase() + topic.slice(1);
      
      setRepurposedContent({
        blog: `# The Ultimate Guide to ${topicCap}: Everything You Need to Know in 2024

*Last updated: ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}*

---

## Introduction

If you've been curious about ${topic}, you're not alone. Millions of people are discovering the incredible potential of ${topic}, and for good reason.

In this comprehensive guide, I'll share everything I've learned about ${topic} – from the fundamentals to advanced strategies that actually work.

**📺 Prefer video? Watch the full breakdown on my YouTube channel: [LINK]**

---

## Table of Contents
1. What is ${topicCap}?
2. Why ${topicCap} Matters in 2024
3. Getting Started: The Basics
4. 5 Strategies That Actually Work
5. Common Mistakes to Avoid
6. Advanced Tips & Tricks
7. Recommended Tools & Resources
8. Frequently Asked Questions
9. Conclusion

---

## What is ${topicCap}?

${topicCap} is [definition]. Unlike other approaches, ${topic} focuses on [key differentiator].

> **Key Insight:** The most successful people in ${topic} share one common trait – they focus on [principle] rather than [common mistake].

---

## Why ${topicCap} Matters in 2024

The landscape of ${topic} has changed dramatically:

- ✅ **Trend 1:** [Explanation]
- ✅ **Trend 2:** [Explanation]  
- ✅ **Trend 3:** [Explanation]

---

## Getting Started: The Basics

### Step 1: Foundation
Before diving deep into ${topic}, you need to understand [fundamental concept].

### Step 2: Tools Setup
Here are the essential tools you'll need:
- Tool 1: [Purpose]
- Tool 2: [Purpose]
- Tool 3: [Purpose]

### Step 3: Your First [Action]
Start small. Your first goal should be [specific, achievable target].

---

## 5 Strategies That Actually Work

### Strategy #1: Start Small, Think Big
Most people fail because they try to do too much too fast.

### Strategy #2: Consistency Over Intensity
Show up every day, even when you don't feel like it.

### Strategy #3: Learn From Failures
Every setback is actually a setup for your next breakthrough.

### Strategy #4: Find Your Community
Nobody succeeds alone in ${topic}.

### Strategy #5: Take Action Today
Information without action is just entertainment.

---

## Recommended Resources

- 📚 Book: "[Title]" by [Author]
- 🎧 Podcast: "[Name]"
- 🛠️ Tool: [Name] - [Affiliate Link]
- 📺 Course: [Name] - [Link]

---

## Conclusion

${topicCap} isn't just a trend – it's a fundamental skill that will continue to grow in importance.

**Ready to take the next step?** Download my free ${topic} cheat sheet below!

[CTA BUTTON: GET FREE CHEAT SHEET]

---

*Did you find this helpful? Share it with someone who needs to see this!*

**Connect with me:**
- YouTube: [Link]
- Instagram: [Link]
- Twitter: [Link]`,

        instagram: `📱 INSTAGRAM REEL SCRIPT
━━━━━━━━━━━━━━━━━━━━━━━━━━

🎬 HOOK (0-3 sec):
"Stop scrolling if you want to master ${topic}"
[TEXT ON SCREEN: "Watch this 👇"]

📝 CONTENT (3-25 sec):
"Here are 3 ${topic} secrets nobody talks about:

Number 1: [Point with quick visual]
Number 2: [Point with quick visual]  
Number 3: [Point with quick visual]"

🎯 CTA (25-30 sec):
"Save this for later and follow for more ${topic} tips!"

━━━━━━━━━━━━━━━━━━━━━━━━━━

📝 INSTAGRAM CAPTION:

The ${topic} game-changer nobody talks about 👇

I spent [time] learning ${topic}, and here's what I wish I knew from day one:

✨ Secret #1: [Brief explanation]
✨ Secret #2: [Brief explanation]
✨ Secret #3: [Brief explanation]

The truth? Most people overcomplicate ${topic}. 

Start with these fundamentals and you'll be ahead of 90% of people.

💬 Which tip surprised you the most? Drop a comment!

🔗 Full video breakdown in bio

.
.
.
#${topic.replace(/\s+/g, '')} #${topic.replace(/\s+/g, '')}tips #learnon #growthmindset #personaldevelopment #successmindset #motivation #entrepreneur #selfimprovement #educationaltiktok #viral #trending #fyp #explorepage`,

        tiktok: `📱 TIKTOK SCRIPT
━━━━━━━━━━━━━━━━━━━━━━━━━━

🎬 FORMAT: Talking head with text overlay
⏱️ LENGTH: 30-60 seconds
🎵 SOUND: Trending audio or original

━━━━━━━━━━━━━━━━━━━━━━━━━━

⚡ HOOK (0-2 sec):
"POV: You finally understand ${topic}"
[Relatable facial expression]

OR

"${topicCap} tip that took me [time] to learn:"

━━━━━━━━━━━━━━━━━━━━━━━━━━

📝 CONTENT (2-25 sec):

OPTION A - Story Format:
"So I was [situation] when I discovered [insight about ${topic}]. And honestly? It changed everything.

Here's what nobody tells you: [key insight]

The moment I realized this, [result]."

OPTION B - List Format:
"3 ${topic} hacks that actually work:

First: [tip] - this alone will [benefit]
Second: [tip] - game changer for [outcome]  
Third: [tip] - most people skip this but [impact]"

━━━━━━━━━━━━━━━━━━━━━━━━━━

🎯 CTA (last 3-5 sec):
"Follow for more ${topic} tips that actually make sense"

OR

"Part 2? Comment '${topic}' if you want it"

━━━━━━━━━━━━━━━━━━━━━━━━━━

📝 TIKTOK CAPTION:
This ${topic} hack is insane 🤯 #${topic.replace(/\s+/g, '')} #${topic.replace(/\s+/g, '')}tok #learnontiktok #edutok #fyp #viral

━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 PRO TIPS:
• Film in 9:16 vertical
• Add captions (80% watch without sound)
• Use trending sounds when relevant
• Post 2-3x per day for growth
• Engage in comments immediately`,

        threads: `📱 THREADS POST
━━━━━━━━━━━━━━━━━━━━━━━━━━

🧵 THREAD 1/7 - HOOK:
"I spent the last [time] mastering ${topic}.

Here are 5 lessons that would've saved me months of struggle:

🧵👇"

━━━━━━━━━━━━━━━━━━━━━━━━━━

🧵 THREAD 2/7:
"Lesson 1: Start before you're ready

The biggest ${topic} myth? That you need [thing] before starting.

Truth: Action creates clarity. Start messy."

━━━━━━━━━━━━━━━━━━━━━━━━━━

🧵 THREAD 3/7:
"Lesson 2: Consistency beats intensity

3 people who succeeded at ${topic}:
• [Example 1]
• [Example 2]
• [Example 3]

What do they share? They showed up daily."

━━━━━━━━━━━━━━━━━━━━━━━━━━

🧵 THREAD 4/7:
"Lesson 3: Your network is your net worth

The fastest way to succeed in ${topic}?

Find 5 people doing what you want to do.

Study them. Reach out. Add value first."

━━━━━━━━━━━━━━━━━━━━━━━━━━

🧵 THREAD 5/7:
"Lesson 4: Failure is data, not destiny

My biggest ${topic} failure: [brief story]

What I learned: [key takeaway]

Every setback contains a lesson if you look for it."

━━━━━━━━━━━━━━━━━━━━━━━━━━

🧵 THREAD 6/7:
"Lesson 5: Document the journey

Your ${topic} journey is content:
• Share wins
• Share struggles  
• Share insights

Authenticity > Perfection"

━━━━━━━━━━━━━━━━━━━━━━━━━━

🧵 THREAD 7/7:
"That's the blueprint.

If this helped, share it with someone who needs it.

And follow @[yourhandle] for more ${topic} insights.

What lesson hit hardest? 👇"`,

        twitter: `🐦 TWITTER/X THREAD
━━━━━━━━━━━━━━━━━━━━━━━━━━

Tweet 1 (Hook):
"I've studied ${topic} for [time].

Here are 10 lessons most people learn too late:

🧵"

━━━━━━━━━━━━━━━━━━━━━━━━━━

Tweet 2:
"1/ The 1% rule

Improve at ${topic} by just 1% daily.

In one year, you'll be 37x better.

Small progress compounds into massive results."

━━━━━━━━━━━━━━━━━━━━━━━━━━

Tweet 3:
"2/ The 80/20 principle

20% of ${topic} strategies drive 80% of results.

Find what works. Double down. Ignore the rest."

━━━━━━━━━━━━━━━━━━━━━━━━━━

Tweet 4:
"3/ The compound effect

Day 1: invisible progress
Day 30: small wins
Day 365: unrecognizable transformation

${topicCap} rewards patience."

━━━━━━━━━━━━━━━━━━━━━━━━━━

Tweet 5-10: [Continue pattern with more insights]

━━━━━━━━━━━━━━━━━━━━━━━━━━

Final Tweet:
"That's the thread.

TL;DR:
• Start before you're ready
• Consistency > intensity
• Learn from failures
• Build in public
• Play long-term games

Follow @[handle] for more ${topic} insights.

RT the first tweet to help others 🙏"

━━━━━━━━━━━━━━━━━━━━━━━━━━

📝 STANDALONE TWEETS:

Tweet A:
"Unpopular ${topic} opinion:

[Contrarian take]

Here's why: [Brief explanation]

Agree or disagree?"

Tweet B:
"${topicCap} simplified:

Step 1: [Action]
Step 2: [Action]
Step 3: [Action]

That's it. Stop overcomplicating it."

Tweet C:
"The ${topic} iceberg:

What people see: [surface level]
What it actually takes: [hidden effort]

Respect the process."`,

        linkedin: `💼 LINKEDIN POST
━━━━━━━━━━━━━━━━━━━━━━━━━━

I failed at ${topic} for 2 years straight.

Then everything changed.

Here's what I learned:

---

In 2022, I was [situation]. I thought I knew ${topic}.

I was wrong.

After [specific struggle], I realized the problem wasn't the strategy.

It was my approach.

Here are 5 mindset shifts that transformed my ${topic} results:

𝟭. 𝗣𝗿𝗼𝗰𝗲𝘀𝘀 > 𝗢𝘂𝘁𝗰𝗼𝗺𝗲𝘀
I stopped chasing results and started building systems.

𝟮. 𝗖𝘂𝗿𝗶𝗼𝘀𝗶𝘁𝘆 > 𝗘𝗴𝗼
I asked more questions. Admitted what I didn't know.

𝟯. 𝗖𝗼𝗻𝘀𝗶𝘀𝘁𝗲𝗻𝗰𝘆 > 𝗜𝗻𝘁𝗲𝗻𝘀𝗶𝘁𝘆
Daily small actions > occasional big efforts.

𝟰. 𝗖𝗼𝗺𝗺𝘂𝗻𝗶𝘁𝘆 > 𝗖𝗼𝗺𝗽𝗲𝘁𝗶𝘁𝗶𝗼𝗻
I surrounded myself with people ahead of me.

𝟱. 𝗔𝗰𝘁𝗶𝗼𝗻 > 𝗣𝗲𝗿𝗳𝗲𝗰𝘁𝗶𝗼𝗻
I shipped before I was ready. Always.

---

The result?

[Specific achievement or transformation]

---

If you're struggling with ${topic}, remember:

You're not behind.
You're not broken.
You're just one mindset shift away.

---

♻️ Repost if this resonates
🔔 Follow for more ${topic} insights

What's YOUR biggest ${topic} challenge? Drop it below 👇

#${topic.replace(/\s+/g, '')} #professionaldevelopment #growthmindset #careergrowth #learning #personaldevelopment`,
      });
      setIsGenerating(false);
    }, 1500);
  };

  const tabs = [
    { id: 'blog', label: '📝 Blog Post', color: 'orange' },
    { id: 'instagram', label: '📸 Instagram', color: 'pink' },
    { id: 'tiktok', label: '🎵 TikTok', color: 'cyan' },
    { id: 'threads', label: '🧵 Threads', color: 'gray' },
    { id: 'twitter', label: '🐦 Twitter/X', color: 'blue' },
    { id: 'linkedin', label: '💼 LinkedIn', color: 'indigo' },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-orange-500 to-amber-500 rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">♻️ Content Repurposer</h2>
        <p className="opacity-90">Turn your video into blog posts, reels, TikToks, threads & more</p>
      </div>

      <div className="flex gap-4">
        <input
          type="text"
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder="Enter your video topic..."
          className="flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-orange-500 focus:border-transparent transition"
        />
        <button
          onClick={generateContent}
          disabled={!topic.trim() || isGenerating}
          className="px-6 py-3 bg-gradient-to-r from-orange-500 to-amber-500 text-white font-bold rounded-xl hover:opacity-90 transition disabled:opacity-50"
        >
          {isGenerating ? '⏳' : '♻️'} Repurpose
        </button>
      </div>

      {repurposedContent && (
        <div className="space-y-4">
          {/* Tabs */}
          <div className="flex flex-wrap gap-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                  activeTab === tab.id
                    ? 'bg-gray-800 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-gray-800">
                {tabs.find(t => t.id === activeTab)?.label} Content
              </h3>
              <button
                onClick={() => navigator.clipboard.writeText(repurposedContent[activeTab as keyof typeof repurposedContent])}
                className="px-4 py-2 bg-orange-500 text-white rounded-lg text-sm hover:bg-orange-600 transition"
              >
                📋 Copy
              </button>
            </div>
            <pre className="whitespace-pre-wrap text-sm text-gray-700 bg-gray-50 p-4 rounded-xl max-h-[500px] overflow-y-auto font-mono leading-relaxed">
              {repurposedContent[activeTab as keyof typeof repurposedContent]}
            </pre>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
            {tabs.map((tab) => (
              <div key={tab.id} className="bg-gray-50 rounded-xl p-3 text-center">
                <div className="text-2xl mb-1">{tab.label.split(' ')[0]}</div>
                <div className="text-xs text-gray-500">Ready to post</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
