import { useState } from 'react';

interface Tool {
  name: string;
  description: string;
  category: string;
  price: string;
  url: string;
  rating: number;
  features: string[];
}

export default function ToolsLibrary() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const tools: Tool[] = [
    // AI Writing
    {
      name: 'ChatGPT',
      description: 'AI assistant for script writing, brainstorming, and content creation',
      category: 'writing',
      price: 'Free / $20/mo',
      url: 'https://chat.openai.com',
      rating: 5,
      features: ['Script writing', 'Brainstorming', 'Research', 'SEO optimization'],
    },
    {
      name: 'Claude',
      description: 'Advanced AI for long-form content and detailed analysis',
      category: 'writing',
      price: 'Free / $20/mo',
      url: 'https://claude.ai',
      rating: 5,
      features: ['Long-form content', 'Analysis', 'Research', 'Coding help'],
    },
    {
      name: 'Jasper',
      description: 'AI marketing platform for creating content at scale',
      category: 'writing',
      price: '$49/mo',
      url: 'https://jasper.ai',
      rating: 4,
      features: ['Templates', 'Brand voice', 'Team collaboration', 'Integrations'],
    },
    // AI Voice
    {
      name: 'ElevenLabs',
      description: 'Ultra-realistic AI voice generation with voice cloning',
      category: 'voice',
      price: 'Free / $5/mo',
      url: 'https://elevenlabs.io',
      rating: 5,
      features: ['Voice cloning', 'Multiple languages', 'Emotion control', 'API access'],
    },
    {
      name: 'Murf.AI',
      description: 'Professional AI voiceover with video editing capabilities',
      category: 'voice',
      price: '$19/mo',
      url: 'https://murf.ai',
      rating: 4,
      features: ['120+ voices', 'Video editor', 'Pitch control', 'Commercial license'],
    },
    {
      name: 'Play.ht',
      description: 'Large library of AI voices with podcast hosting',
      category: 'voice',
      price: 'Free / $14/mo',
      url: 'https://play.ht',
      rating: 4,
      features: ['900+ voices', 'Podcast hosting', 'WordPress plugin', 'API'],
    },
    // Video Editing
    {
      name: 'Pictory',
      description: 'Turn scripts and blogs into videos automatically',
      category: 'editing',
      price: '$23/mo',
      url: 'https://pictory.ai',
      rating: 4,
      features: ['Script to video', 'Auto-captions', 'Stock footage', 'Branding'],
    },
    {
      name: 'InVideo',
      description: '5000+ templates for quick video creation',
      category: 'editing',
      price: 'Free / $15/mo',
      url: 'https://invideo.io',
      rating: 4,
      features: ['Templates', 'AI editor', 'Stock media', 'Team features'],
    },
    {
      name: 'CapCut',
      description: 'Free, powerful editor with auto-captions and effects',
      category: 'editing',
      price: 'Free',
      url: 'https://capcut.com',
      rating: 5,
      features: ['Auto captions', 'Effects', 'Templates', 'Mobile + desktop'],
    },
    {
      name: 'Descript',
      description: 'Edit video by editing text - magical experience',
      category: 'editing',
      price: 'Free / $12/mo',
      url: 'https://descript.com',
      rating: 5,
      features: ['Text-based editing', 'Overdub', 'Screen recording', 'Filler removal'],
    },
    {
      name: 'Opus Clip',
      description: 'Auto-generates shorts from long-form videos',
      category: 'editing',
      price: 'Free / $9/mo',
      url: 'https://opus.pro',
      rating: 4,
      features: ['AI clip detection', 'Viral scores', 'Auto reframe', 'Captions'],
    },
    // Stock Footage
    {
      name: 'Pexels',
      description: 'Free high-quality stock videos and photos',
      category: 'footage',
      price: 'Free',
      url: 'https://pexels.com',
      rating: 5,
      features: ['Free', 'No attribution', 'High quality', 'Large library'],
    },
    {
      name: 'Storyblocks',
      description: 'Unlimited downloads of stock video, audio, images',
      category: 'footage',
      price: '$15/mo',
      url: 'https://storyblocks.com',
      rating: 5,
      features: ['Unlimited downloads', 'Video + audio + images', '4K content', 'Templates'],
    },
    {
      name: 'Artgrid',
      description: 'Cinematic stock footage from filmmakers',
      category: 'footage',
      price: '$25/mo',
      url: 'https://artgrid.io',
      rating: 4,
      features: ['Cinematic quality', '4K/8K footage', 'RAW files', 'Filmmaker-shot'],
    },
    // SEO & Analytics
    {
      name: 'TubeBuddy',
      description: 'YouTube SEO and channel management tool',
      category: 'seo',
      price: 'Free / $4/mo',
      url: 'https://tubebuddy.com',
      rating: 5,
      features: ['Keyword research', 'A/B testing', 'Best time to post', 'Tag suggestions'],
    },
    {
      name: 'VidIQ',
      description: 'YouTube analytics and optimization platform',
      category: 'seo',
      price: 'Free / $7/mo',
      url: 'https://vidiq.com',
      rating: 5,
      features: ['SEO score', 'Competitor analysis', 'Trend alerts', 'AI titles'],
    },
    // Thumbnails
    {
      name: 'Canva',
      description: 'Easy-to-use design tool with YouTube templates',
      category: 'design',
      price: 'Free / $12/mo',
      url: 'https://canva.com',
      rating: 5,
      features: ['Templates', 'Brand kit', 'Team collaboration', 'AI features'],
    },
    {
      name: 'Photopea',
      description: 'Free Photoshop alternative in the browser',
      category: 'design',
      price: 'Free',
      url: 'https://photopea.com',
      rating: 4,
      features: ['PSD support', 'Advanced editing', 'No download needed', 'Free'],
    },
    // AI Video Generation
    {
      name: 'Runway ML',
      description: 'AI video generation and editing tools',
      category: 'ai-video',
      price: '$12/mo',
      url: 'https://runwayml.com',
      rating: 4,
      features: ['Text to video', 'Video to video', 'Green screen', 'Motion brush'],
    },
    {
      name: 'Synthesia',
      description: 'Create videos with AI avatars',
      category: 'ai-video',
      price: '$22/mo',
      url: 'https://synthesia.io',
      rating: 4,
      features: ['AI avatars', '120+ languages', 'Custom avatars', 'Templates'],
    },
    {
      name: 'HeyGen',
      description: 'AI spokesperson videos with natural lip-sync',
      category: 'ai-video',
      price: '$24/mo',
      url: 'https://heygen.com',
      rating: 4,
      features: ['AI avatars', 'Voice cloning', 'Video translation', 'Templates'],
    },
  ];

  const categories = [
    { id: 'all', label: '🎯 All Tools' },
    { id: 'writing', label: '📝 AI Writing' },
    { id: 'voice', label: '🎙️ AI Voice' },
    { id: 'editing', label: '✂️ Video Editing' },
    { id: 'footage', label: '🎥 Stock Footage' },
    { id: 'seo', label: '🔍 SEO & Analytics' },
    { id: 'design', label: '🎨 Thumbnails' },
    { id: 'ai-video', label: '🤖 AI Video' },
  ];

  const filteredTools = tools.filter((tool) => {
    const matchesCategory = activeCategory === 'all' || tool.category === activeCategory;
    const matchesSearch = tool.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          tool.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-cyan-500 to-blue-500 rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">🛠️ Creator Tools Library</h2>
        <p className="opacity-90">All the tools you need to automate your faceless YouTube channel</p>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col md:flex-row gap-4">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search tools..."
          className="flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition"
        />
      </div>

      {/* Categories */}
      <div className="flex flex-wrap gap-2">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition ${
              activeCategory === cat.id
                ? 'bg-cyan-500 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Tools Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTools.map((tool, idx) => (
          <div key={idx} className="bg-white rounded-2xl p-5 border border-gray-200 shadow-sm hover:shadow-md transition">
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-bold text-gray-800 text-lg">{tool.name}</h3>
              <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                {tool.price}
              </span>
            </div>
            <p className="text-gray-600 text-sm mb-3">{tool.description}</p>
            <div className="flex items-center gap-1 mb-3">
              {[...Array(5)].map((_, i) => (
                <span key={i} className={i < tool.rating ? 'text-yellow-400' : 'text-gray-200'}>★</span>
              ))}
            </div>
            <div className="flex flex-wrap gap-1 mb-4">
              {tool.features.slice(0, 3).map((feature, i) => (
                <span key={i} className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded text-xs">
                  {feature}
                </span>
              ))}
            </div>
            <a
              href={tool.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full text-center py-2 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg text-sm font-medium hover:opacity-90 transition"
            >
              Visit Site →
            </a>
          </div>
        ))}
      </div>

      {/* Workflow Section */}
      <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-6 border border-gray-200">
        <h3 className="font-bold text-gray-800 text-xl mb-4">🚀 Recommended Automation Workflow</h3>
        <div className="grid md:grid-cols-5 gap-4">
          {[
            { step: 1, tool: 'ChatGPT', action: 'Write Script', icon: '📝' },
            { step: 2, tool: 'ElevenLabs', action: 'Generate Voice', icon: '🎙️' },
            { step: 3, tool: 'Pictory', action: 'Create Video', icon: '🎬' },
            { step: 4, tool: 'CapCut', action: 'Add Captions', icon: '📋' },
            { step: 5, tool: 'TubeBuddy', action: 'Optimize SEO', icon: '🔍' },
          ].map((item) => (
            <div key={item.step} className="text-center">
              <div className="w-12 h-12 mx-auto bg-cyan-500 text-white rounded-full flex items-center justify-center text-xl mb-2">
                {item.icon}
              </div>
              <div className="text-xs text-gray-500 mb-1">Step {item.step}</div>
              <div className="font-medium text-gray-800 text-sm">{item.tool}</div>
              <div className="text-xs text-gray-500">{item.action}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
