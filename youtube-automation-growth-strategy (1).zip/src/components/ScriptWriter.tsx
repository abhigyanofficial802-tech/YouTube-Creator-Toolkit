import { useState } from 'react';

interface ScriptWriterProps {
  topic: string;
  setTopic: (topic: string) => void;
}

export default function ScriptWriter({ topic, setTopic }: ScriptWriterProps) {
  const [scriptType, setScriptType] = useState('full');
  const [generatedScript, setGeneratedScript] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const generateScript = () => {
    if (!topic.trim()) return;
    setIsGenerating(true);
    
    setTimeout(() => {
      const scripts: Record<string, string> = {
        full: `🎬 FULL VIDEO SCRIPT: "${topic.toUpperCase()}"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🪝 HOOK (0:00 - 0:15)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

"What if I told you that 90% of people who try ${topic} fail within the first month? But here's the thing – the other 10% aren't smarter, luckier, or more talented. They just know ONE secret that changes everything. And by the end of this video, you'll know it too."

[VISUAL: Quick montage of success/failure contrast]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📖 THE STORY (0:15 - 3:00)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

"Let me tell you about someone named Alex. Just 18 months ago, Alex was exactly where you might be right now – curious about ${topic}, but completely overwhelmed by all the information out there.

Alex tried everything. Watched countless videos, read every article, even bought courses. But nothing seemed to work. The breakthrough came when Alex discovered something counterintuitive...

[PAUSE FOR EFFECT]

Instead of trying to learn everything at once, Alex focused on just ONE fundamental principle. And that's exactly what I'm going to share with you today."

[VISUAL: Story animation or relevant B-roll]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💡 MAIN CONTENT (3:00 - 8:00)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

"Here are the 5 key principles of ${topic} that will transform your approach:

**Principle #1: Start Small, Think Big**
Most people fail because they try to do too much too fast. The secret is to start with micro-actions that compound over time.

**Principle #2: Consistency Over Intensity**
It's not about going all-in for a week. It's about showing up every single day, even when you don't feel like it.

**Principle #3: Learn From Failures**
Every setback is actually a setup for your next breakthrough. Document what doesn't work – it's just as valuable as knowing what does.

**Principle #4: Find Your Community**
Nobody succeeds alone. Surround yourself with people who are on the same journey.

**Principle #5: Take Action Today**
Information without action is just entertainment. You need to implement what you learn immediately."

[VISUAL: Animated graphics for each principle]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 CALL TO ACTION (8:00 - 8:30)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

"Now here's what I want you to do RIGHT NOW:

1. Drop a comment below telling me which principle resonated with you the most
2. Hit that subscribe button if you want more content like this
3. Share this video with someone who needs to hear this message

And if you're ready to take your ${topic} journey to the next level, check out my free guide in the description below.

I'll see you in the next one. Let's go! 🚀"

[END SCREEN: Subscribe animation + Related video suggestions]`,

        intro: `🎬 15-SECOND INTRO: "${topic.toUpperCase()}"

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⏱️ SECOND 0-3:
"Stop scrolling. This is important."
[VISUAL: Pattern interrupt - Bold text on screen]

⏱️ SECOND 3-8:
"I just discovered something about ${topic} that nobody is talking about – and it could change everything for you."
[VISUAL: Quick cuts, energetic music]

⏱️ SECOND 8-12:
"In the next few minutes, I'm going to show you exactly how to [key benefit] without [common pain point]."
[VISUAL: Preview of main content/results]

⏱️ SECOND 12-15:
"Trust me, you're going to want to watch until the end."
[VISUAL: Transition to main content]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📝 ALTERNATIVE HOOKS:

OPTION A - Curiosity Gap:
"What if everything you knew about ${topic} was completely wrong?"

OPTION B - Bold Claim:
"I'm about to show you the #1 secret that top experts in ${topic} don't want you to know."

OPTION C - Story Tease:
"Last week, someone messaged me saying this video changed their life. Here's why..."

OPTION D - Controversy:
"I'm probably going to get hate for this, but someone needs to say it about ${topic}..."`,

        faceless: `🎬 FACELESS CHANNEL AUTOMATION GUIDE

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📝 STEP 1: SCRIPT WRITING WITH AI
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**ChatGPT Prompts for ${topic} Scripts:**

Prompt 1 - Research:
"Act as a YouTube content strategist. Research the top 10 trending topics about ${topic} that would perform well on YouTube. Include potential titles and why they'd get clicks."

Prompt 2 - Script Writing:
"Write a 10-minute YouTube script about [specific topic]. Include:
- An attention-grabbing hook (first 15 seconds)
- A relatable story or example
- 5 actionable tips with explanations
- A strong call to action
- Timestamps for each section"

Prompt 3 - Optimization:
"Rewrite this script to be more conversational and engaging. Add power words, rhetorical questions, and emotional triggers."

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎙️ STEP 2: AI VOICE NARRATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Recommended AI Voice Tools:**

1. **ElevenLabs** (Best Quality)
   - Ultra-realistic voices
   - Custom voice cloning
   - $5/month starter plan

2. **Murf.AI** (Great for Business)
   - 120+ voices in 20 languages
   - Built-in video editor
   - Studio-quality output

3. **Play.ht** (Budget-Friendly)
   - 900+ AI voices
   - Free tier available
   - API access for automation

4. **LOVO** (All-in-One)
   - Voice + video editing
   - Emotional voice control
   - Good for beginners

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎥 STEP 3: STOCK FOOTAGE SOURCES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Free Options:**
• Pexels.com - High-quality free videos
• Pixabay.com - Huge library, no attribution
• Coverr.co - Beautiful B-roll footage
• Mixkit.co - Premium-quality free clips

**Paid Options:**
• Storyblocks - $15/month unlimited downloads
• Artgrid - Cinematic footage
• Envato Elements - All-in-one creative assets

**AI-Generated:**
• Runway ML - Generate custom footage
• Pika Labs - Text-to-video
• Synthesia - AI avatar videos

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✂️ STEP 4: EDITING AUTOMATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**AI Editing Tools:**

1. **Pictory** - Auto-creates videos from scripts
2. **InVideo** - Templates + AI assistance
3. **Descript** - Edit video like a doc
4. **CapCut** - Free, powerful, auto-captions
5. **Opus Clip** - Auto-creates shorts from long videos

**Automation Workflow:**
1. Write script with ChatGPT
2. Generate voiceover with ElevenLabs
3. Import to Pictory/InVideo
4. Auto-match stock footage
5. Add captions with CapCut
6. Export and upload

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💰 STEP 5: MONETIZATION TIMELINE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Month 1-3:** Build foundation (50+ videos)
**Month 3-6:** Reach 1K subs, 4K watch hours
**Month 6-12:** AdSense approval + affiliate marketing
**Year 2+:** Sponsorships + digital products

**Revenue Streams:**
• YouTube AdSense
• Affiliate marketing
• Sponsored content
• Digital products
• Coaching/consulting`
      };

      setGeneratedScript(scripts[scriptType] || scripts.full);
      setIsGenerating(false);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-red-500 to-pink-500 rounded-2xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">📝 AI Script Writer</h2>
        <p className="opacity-90">Generate engaging YouTube scripts with hooks, stories, and CTAs</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Video Topic</label>
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g., trading, fitness, productivity..."
            className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-red-500 focus:border-transparent transition"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Script Type</label>
          <select
            value={scriptType}
            onChange={(e) => setScriptType(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-red-500 focus:border-transparent transition"
          >
            <option value="full">Full Video Script</option>
            <option value="intro">15-Second Hook/Intro</option>
            <option value="faceless">Faceless Channel Guide</option>
          </select>
        </div>
      </div>

      <button
        onClick={generateScript}
        disabled={!topic.trim() || isGenerating}
        className="w-full py-4 bg-gradient-to-r from-red-500 to-pink-500 text-white font-bold rounded-xl hover:opacity-90 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
      >
        {isGenerating ? (
          <>
            <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
            Generating Script...
          </>
        ) : (
          <>
            ✨ Generate Script
          </>
        )}
      </button>

      {generatedScript && (
        <div className="bg-gray-50 rounded-2xl p-6 border border-gray-200">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-gray-800">Generated Script</h3>
            <button
              onClick={() => navigator.clipboard.writeText(generatedScript)}
              className="px-4 py-2 bg-gray-800 text-white rounded-lg text-sm hover:bg-gray-700 transition"
            >
              📋 Copy
            </button>
          </div>
          <pre className="whitespace-pre-wrap text-sm text-gray-700 font-mono leading-relaxed max-h-[500px] overflow-y-auto">
            {generatedScript}
          </pre>
        </div>
      )}
    </div>
  );
}
